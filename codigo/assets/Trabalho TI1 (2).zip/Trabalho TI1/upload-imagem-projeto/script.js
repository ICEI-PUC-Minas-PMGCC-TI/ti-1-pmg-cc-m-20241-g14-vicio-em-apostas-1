// Função para limpar todas as imagens do servidor JSON
function clearImages() {
    fetch('http://localhost:3000/images', {
        method: 'DELETE'
    })
    .then(response => {
        if (response.ok) {
            console.log('Todas as imagens foram removidas com sucesso.');
            displayImages(); // Atualiza a exibição das imagens após remover todas
        } else {
            console.error('Erro ao remover as imagens.');
        }
    })
    .catch(error => {
        console.error('Error deleting images:', error);
    });
}

// Adiciona um event listener para o envio do formulário
document.getElementById('uploadForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Impede o envio padrão do formulário
    const imageInput = document.getElementById('imageInput');
    if (imageInput.files && imageInput.files[0]) {
        const formData = new FormData();
        formData.append('image', imageInput.files[0]);

        // Envia a imagem para o servidor
        uploadImage(formData);
    }
});

// Função para enviar a imagem para o servidor
function uploadImage(formData) {
    fetch('http://localhost:3001/upload', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        // Depois de enviar a imagem, salva a URL da imagem no servidor JSON
        saveImageInfo(data.imageUrl);
    })
    .catch(error => {
        console.error('Error uploading image:', error);
    });
}

// Função para salvar a URL da imagem no servidor JSON
function saveImageInfo(imageUrl) {
    fetch('http://localhost:3000/images', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ url: imageUrl })
    })
    .then(response => response.json())
    .then(data => {
        // Após salvar a URL da imagem, atualiza a lista de imagens exibidas
        displayImages();
    })
    .catch(error => {
        console.error('Error saving image info:', error);
    });
}

// Função para exibir as imagens
function displayImages() {
    fetch('http://localhost:3000/images')
    .then(response => response.json())
    .then(images => {
        const imageList = document.getElementById('imageList');
        imageList.innerHTML = ''; // Limpa a lista de imagens antes de exibir as novas imagens
        images.forEach(image => {
            // Cria um elemento de imagem para cada URL de imagem e adiciona à lista de imagens
            const imgElement = document.createElement('img');
            imgElement.src = image.url;
            imgElement.style.width = '200px'; // Define o tamanho da imagem conforme necessário
            imgElement.style.margin = '10px'; // Define a margem da imagem conforme necessário
            imageList.appendChild(imgElement);
        });
    })
    .catch(error => {
        console.error('Error fetching images:', error);
    });
}

// Chama a função displayImages quando a página é carregada para exibir as imagens existentes
document.addEventListener('DOMContentLoaded', displayImages);
// Função para excluir uma imagem específica do servidor JSON
function deleteImage(imageId) {
    fetch(`http://localhost:3000/images/${imageId}`, {
        method: 'DELETE'
    })
    .then(response => {
        if (response.ok) {
            console.log('Imagem excluída com sucesso.');
            displayImages(); // Atualiza a exibição das imagens após a exclusão
        } else {
            console.error('Erro ao excluir a imagem.');
        }
    })
    .catch(error => {
        console.error('Error deleting image:', error);
    });
}

// Função para exibir as imagens
function displayImages() {
    fetch('http://localhost:3000/images')
    .then(response => response.json())
    .then(images => {
        const imageList = document.getElementById('imageList');
        imageList.innerHTML = ''; // Limpa a lista de imagens antes de exibir as novas imagens
        images.forEach(image => {
            // Cria um contêiner para a imagem e o botão de exclusão
            const container = document.createElement('div');

            // Cria um elemento de imagem para cada URL de imagem
            const imgElement = document.createElement('img');
            imgElement.src = image.url;
            imgElement.style.width = '200px'; // Define o tamanho da imagem conforme necessário

            // Cria um botão de exclusão para a imagem
            const deleteButton = document.createElement('button');
            deleteButton.textContent = 'Excluir';
            deleteButton.addEventListener('click', () => {
                // Quando o botão de exclusão é clicado, chama a função deleteImage com o ID da imagem
                deleteImage(image.id);
            });

            // Adiciona a imagem e o botão de exclusão ao contêiner
            container.appendChild(imgElement);
            container.appendChild(deleteButton);

            // Adiciona o contêiner à lista de imagens
            imageList.appendChild(container);
        });
    })
    .catch(error => {
        console.error('Error fetching images:', error);
    });
}

// Chama a função displayImages quando a página é carregada para exibir as imagens existentes
document.addEventListener('DOMContentLoaded', displayImages);
