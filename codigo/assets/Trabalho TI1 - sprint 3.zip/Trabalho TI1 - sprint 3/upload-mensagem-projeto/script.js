// Função para limpar todas as mensagens do servidor JSON
function clearMessages() {
    fetch('http://localhost:3000/messages', {
        method: 'DELETE'
    })
    .then(response => {
        if (response.ok) {
            console.log('Todas as mensagens foram removidas com sucesso.');
            displayMessages(); // Atualiza a exibição das mensagens após remover todas
        } else {
            console.error('Erro ao remover as mensagens.');
        }
    })
    .catch(error => {
        console.error('Error deleting messages:', error);
    });
}

// Adiciona um event listener para o envio do formulário de mensagem
document.getElementById('messageForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Impede o envio padrão do formulário
    const messageInput = document.getElementById('messageInput');
    const messageText = messageInput.value;
    if (messageText.trim() !== '') {
        // Envia a mensagem para o servidor
        sendMessage(messageText);
    }
});

// Função para enviar a mensagem para o servidor
function sendMessage(messageText) {
    fetch('http://localhost:3000/messages', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ text: messageText })
    })
    .then(response => response.json())
    .then(data => {
        // Após enviar a mensagem, atualiza a lista de mensagens exibidas
        displayMessages();
    })
    .catch(error => {
        console.error('Error sending message:', error);
    });
}

// Função para exibir as mensagens
function displayMessages() {
    fetch('http://localhost:3000/messages')
    .then(response => response.json())
    .then(messages => {
        const messagesDiv = document.getElementById('messages');
        messagesDiv.innerHTML = ''; // Limpa a div de mensagens antes de exibir as novas mensagens
        messages.forEach(message => {
            // Cria um elemento de mensagem para cada texto de mensagem e adiciona à div de mensagens
            const messageElement = document.createElement('div');
            messageElement.className = 'message';
            messageElement.textContent = message.text;
            messagesDiv.appendChild(messageElement);
        });
    })
    .catch(error => {
        console.error('Error fetching messages:', error);
    });
}

// Chama a função displayMessages quando a página é carregada para exibir as mensagens existentes
document.addEventListener('DOMContentLoaded', displayMessages);
