const express = require('express');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json()); // Middleware para análise de JSON

// Dados simulados de mensagens
let messages = [];

// Rota para obter todas as mensagens
app.get('/messages', (req, res) => {
    res.json(messages);
});

// Rota para adicionar uma nova mensagem
app.post('/messages', (req, res) => {
    const { text } = req.body;
    if (!text) {
        return res.status(400).json({ error: 'Please provide a message text.' });
    }
    const newMessage = { id: messages.length + 1, text };
    messages.push(newMessage);
    res.status(201).json(newMessage);
});

// Rota para excluir uma mensagem por ID
app.delete('/messages/:id', (req, res) => {
    const { id } = req.params;
    const index = messages.findIndex(message => message.id === parseInt(id));
    if (index === -1) {
        return res.status(404).json({ error: 'Message not found.' });
    }
    messages.splice(index, 1);
    res.status(204).end();
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
